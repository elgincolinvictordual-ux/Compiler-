/* synthetic */ module org.json {
    exports org.json;

}

