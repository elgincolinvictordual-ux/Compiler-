/*
 * Decompiled with CFR.
 */
package net.rwee.drill;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.rwee.drill.command.DrillCommand;
import net.rwee.drill.command.DrillTabCompleter;
import net.rwee.drill.listener.DrillPickaxeListener;
import net.rwee.drill.listener.DrillProtectionListener;
import net.rwee.drill.metrics.bukkit.Metrics;
import net.rwee.drill.protection.FactionsUUIDHook;
import net.rwee.drill.protection.GriefPreventionHook;
import net.rwee.drill.protection.LandProtectionManager;
import net.rwee.drill.protection.LandsHook;
import net.rwee.drill.recipe.RecipeManager;
import net.rwee.drill.task.DrillSelfDestructTask;
import net.rwee.drill.utils.DrillUtils;
import net.rwee.drill.utils.License;
import net.rwee.drill.utils.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class DrillPickaxePlugin
extends JavaPlugin {
    private static DrillPickaxePlugin instance;
    private LandProtectionManager protectionManager;
    private FactionsUUIDHook factionsHook;
    private GriefPreventionHook griefPreventionHook;
    private LandsHook landsHook;
    private License licenseManager;
    private BukkitTask selfDestructTask;
    private MessageManager messageManager;
    private RecipeManager recipeManager;

    public static DrillPickaxePlugin getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        this.saveDefaultConfig();
        String licenseKey = this.getConfig().getString("license-key");
        String productName = "DonutDrillX";
        this.licenseManager = new License(this, productName, licenseKey);
        if (!this.licenseManager.initialize()) {
            this.getLogger().severe("Failed to verify license! Plugin will be disabled.");
            this.getLogger().severe("Please check your license key in config.yml or contact support.");
            this.getServer().getPluginManager().disablePlugin(this);
            return;
        }
        this.getLogger().info("License verified successfully - Loading DonutDrillX...");
        this.messageManager = new MessageManager(this);
        DrillUtils.init(this);
        this.protectionManager = new LandProtectionManager(this);
        this.factionsHook = new FactionsUUIDHook(this);
        this.griefPreventionHook = new GriefPreventionHook(this);
        this.landsHook = new LandsHook(this);
        this.recipeManager = new RecipeManager(this);
        int pluginId = 25720;
        Metrics metrics = new Metrics(this, pluginId);
        Bukkit.getPluginManager().registerEvents(new DrillPickaxeListener(), this);
        Bukkit.getPluginManager().registerEvents(new DrillProtectionListener(), this);
        this.getCommand("drill").setExecutor(new DrillCommand());
        this.getCommand("drill").setTabCompleter(new DrillTabCompleter());
        this.recipeManager.registerAllRecipes();
        this.selfDestructTask = new DrillSelfDestructTask(this).runTaskTimer(this, 0L, 20L);
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31m  ____                    _   ____       _ _ ___  __ \u001b[0m");
        this.getLogger().info("\u001b[31m |  _ \\  ___  _ __  _   _| |_|  _ \\ _ __(_) | \\ \\/ / \u001b[0m");
        this.getLogger().info("\u001b[31m | | | |/ _ \\| '_ \\| | | | __| | | | '__| | | |\\  /  \u001b[0m");
        this.getLogger().info("\u001b[31m | |_| | (_) | | | | |_| | |_| |_| | |  | | | |/  \\  \u001b[0m");
        this.getLogger().info("\u001b[31m |____/ \\___/|_| |_|\\__,_|\\__|____/|_|  |_|_|_/_/\\_\\ \u001b[0m");
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31mDonutDrillX - " + this.getDescription().getVersion() + " (Licensed)\u001b[0m");
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31m Current Java Version: " + System.getProperty("java.version") + " \u001b[0m");
        this.getLogger().info("\u001b[31m Current OS: " + System.getProperty("os.name") + " \u001b[0m");
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31m NOTE: This plugin requires WorldGuard and WorldEdit to use Regions \u001b[0m");
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31m This software is developed by Rwee. All rights reserved. \u001b[0m");
        this.getLogger().info(" ");
        this.getLogger().info("\u001b[31m Loading module: DonutDrillX \u001b[0m");
        boolean multimode = this.getConfig().getBoolean("multimode", false);
        if (multimode) {
            this.getLogger().info("\u001b[31m Multimode enabled - " + DrillUtils.getAvailableDrillNames().size() + " drill types loaded \u001b[0m");
        } else {
            this.getLogger().info("\u001b[31m Legacy mode - Single drill type \u001b[0m");
        }
        this.logProtectionPluginStatus();
        this.getLogger().info("\u001b[31m DonutDrillX loaded successfully! \u001b[0m");
    }

    @Override
    public void onDisable() {
        if (this.recipeManager != null) {
            this.recipeManager.unregisterAllRecipes();
        }
        if (this.selfDestructTask != null) {
            this.selfDestructTask.cancel();
        }
        if (this.licenseManager != null) {
            this.licenseManager.cleanup();
        }
        this.getLogger().info("DonutDrillX has been disabled.");
    }

    private void logProtectionPluginStatus() {
        if (this.factionsHook != null && this.factionsHook.isEnabled()) {
            this.getLogger().info("\u001b[31m Successfully hooked into Factions. \u001b[0m");
        }
        if (this.griefPreventionHook != null && this.griefPreventionHook.isEnabled()) {
            this.getLogger().info("\u001b[31m Successfully hooked into GriefPrevention. \u001b[0m");
        }
        if (this.landsHook != null && this.landsHook.isEnabled()) {
            this.getLogger().info("\u001b[31m Successfully hooked into Lands. \u001b[0m");
        }
    }

    public Set<Material> getBlockedMaterials() {
        List<String> list = this.getConfig().getStringList("drill.blocked-materials");
        HashSet<Material> blocked = new HashSet<Material>();
        for (String name : list) {
            try {
                blocked.add(Material.valueOf(name));
            }
            catch (IllegalArgumentException ignored) {
                this.getLogger().warning("Invalid material in blocked-materials: " + name);
            }
        }
        return blocked;
    }

    public LandProtectionManager getProtectionManager() {
        return this.protectionManager;
    }

    public License getLicenseManager() {
        return this.licenseManager;
    }

    public boolean isLicensed() {
        return this.licenseManager != null && this.licenseManager.isLicensed();
    }

    public MessageManager getMessageManager() {
        return this.messageManager;
    }

    public RecipeManager getRecipeManager() {
        return this.recipeManager;
    }
}

