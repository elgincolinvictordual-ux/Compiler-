/*
 * Decompiled with CFR.
 */
package net.rwee.drill.lib.folialib.wrapper.task;

import org.bukkit.plugin.Plugin;

public interface WrappedTask {
    public void cancel();

    public boolean isCancelled();

    public Plugin getOwningPlugin();

    public boolean isAsync();
}

