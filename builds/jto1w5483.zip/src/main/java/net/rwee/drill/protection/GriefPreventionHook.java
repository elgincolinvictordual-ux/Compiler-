/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  me.ryanhamshire.GriefPrevention.Claim
 *  me.ryanhamshire.GriefPrevention.GriefPrevention
 */
package net.rwee.drill.protection;

import me.ryanhamshire.GriefPrevention.Claim;
import me.ryanhamshire.GriefPrevention.GriefPrevention;
import net.rwee.drill.protection.LandProtectionHook;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class GriefPreventionHook
implements LandProtectionHook {
    private final boolean enabled;

    public GriefPreventionHook(Plugin plugin) {
        boolean pluginEnabled = false;
        try {
            Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
            pluginEnabled = gp != null && gp.isEnabled();
        }
        catch (Exception e) {
            plugin.getLogger().warning("Error initializing GriefPrevention hook: " + e.toString());
        }
        this.enabled = pluginEnabled;
    }

    @Override
    public boolean canBreak(Player player, Block block) {
        if (!this.enabled || GriefPrevention.instance == null || GriefPrevention.instance.dataStore == null) {
            return true;
        }
        Claim claim = GriefPrevention.instance.dataStore.getClaimAt(block.getLocation(), false, null);
        if (claim == null) {
            return true;
        }
        return claim.allowBreak(player, block.getType()) == null;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}

