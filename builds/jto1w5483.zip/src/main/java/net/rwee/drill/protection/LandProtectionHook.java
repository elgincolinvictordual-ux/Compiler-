/*
 * Decompiled with CFR.
 */
package net.rwee.drill.protection;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public interface LandProtectionHook {
    public boolean canBreak(Player var1, Block var2);

    public boolean isEnabled();
}

