/*
 * Decompiled with CFR.
 */
package net.rwee.drill.protection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import net.rwee.drill.protection.LandProtectionHook;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LandsHook
implements LandProtectionHook {
    private final Plugin plugin;
    private Plugin landsPlugin;
    private Object landsIntegration;
    private final ConcurrentHashMap<String, Class<?>> classCache = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Method> methodCache = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Field> fieldCache = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Boolean> permissionCache = new ConcurrentHashMap();
    private static final int MAX_CACHE_SIZE = 1000;

    public LandsHook(Plugin plugin) {
        this.plugin = plugin;
        this.landsPlugin = Bukkit.getPluginManager().getPlugin("Lands");
        if (this.isEnabled()) {
            this.initializeLandsIntegration();
        }
    }

    private void initializeLandsIntegration() {
        try {
            Class<?> landsIntegrationClass = Class.forName("me.angeschossen.lands.api.LandsIntegration");
            Method ofMethod = landsIntegrationClass.getMethod("of", Plugin.class);
            this.landsIntegration = ofMethod.invoke(null, this.plugin);
            this.plugin.getLogger().info("Lands integration initialized successfully");
        }
        catch (Exception e) {
            this.plugin.getLogger().warning("Error initializing Lands hook: " + e.toString());
        }
    }

    private Class<?> getClass(String className) {
        return this.classCache.computeIfAbsent(className, key -> {
            try {
                return Class.forName(key);
            }
            catch (ClassNotFoundException e) {
                return null;
            }
        });
    }

    private Method getMethod(Class<?> clazz, String methodName, Class<?> ... parameterTypes) {
        if (clazz == null) {
            return null;
        }
        String key = clazz.getName() + "#" + methodName + "#" + Arrays.toString(parameterTypes);
        return this.methodCache.computeIfAbsent(key, k -> {
            try {
                return clazz.getMethod(methodName, parameterTypes);
            }
            catch (NoSuchMethodException e) {
                return null;
            }
        });
    }

    private Field getField(Class<?> clazz, String fieldName) {
        if (clazz == null) {
            return null;
        }
        String key = clazz.getName() + "#" + fieldName;
        return this.fieldCache.computeIfAbsent(key, k -> {
            try {
                return clazz.getField(fieldName);
            }
            catch (NoSuchFieldException e) {
                return null;
            }
        });
    }

    @Override
    public boolean canBreak(Player player, Block block) {
        if (!this.isEnabled() || this.landsIntegration == null) {
            return true;
        }
        String cacheKey = String.valueOf(player.getUniqueId()) + ":" + block.getWorld().getName() + ":" + block.getX() + "," + block.getY() + "," + block.getZ();
        if (this.permissionCache.containsKey(cacheKey)) {
            return this.permissionCache.get(cacheKey);
        }
        boolean canBreak = this.checkPermission(player, block);
        if (this.permissionCache.size() >= 1000) {
            this.permissionCache.clear();
        }
        this.permissionCache.put(cacheKey, canBreak);
        return canBreak;
    }

    private boolean checkPermission(Player player, Block block) {
        try {
            if (player.hasPermission("lands.bypass") || player.hasPermission("lands.admin.bypass") || player.isOp()) {
                return true;
            }
            Method getLandPlayerMethod = this.getMethod(this.landsIntegration.getClass(), "getLandPlayer", UUID.class);
            if (getLandPlayerMethod == null) {
                this.plugin.getLogger().warning("Could not find getLandPlayer method");
                return true;
            }
            Object landPlayer = getLandPlayerMethod.invoke(this.landsIntegration, player.getUniqueId());
            if (landPlayer == null) {
                this.plugin.getLogger().warning("Could not get LandPlayer for " + player.getName());
                return true;
            }
            Method getWorldMethod = this.getMethod(this.landsIntegration.getClass(), "getWorld", World.class);
            if (getWorldMethod == null) {
                this.plugin.getLogger().warning("Could not find getWorld method");
                return true;
            }
            Object landWorld = getWorldMethod.invoke(this.landsIntegration, block.getWorld());
            if (landWorld == null) {
                return true;
            }
            Method getAreaMethod = this.getMethod(landWorld.getClass(), "getArea", Integer.TYPE, Integer.TYPE, Integer.TYPE);
            if (getAreaMethod == null) {
                this.plugin.getLogger().warning("Could not find getArea(int, int, int) method");
                return true;
            }
            Object area = getAreaMethod.invoke(landWorld, block.getX(), block.getY(), block.getZ());
            if (area == null) {
                return this.checkWildernessPermission(landWorld, landPlayer, block);
            }
            return this.checkLandPermission(landWorld, landPlayer, area, block);
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Error checking Lands protection", e);
            return false;
        }
    }

    private boolean checkLandPermission(Object landWorld, Object landPlayer, Object area, Block block) {
        try {
            Class<?> flagsClass = this.getClass("me.angeschossen.lands.api.flags.type.Flags");
            if (flagsClass == null) {
                this.plugin.getLogger().warning("Could not find Flags class");
                return true;
            }
            Field blockBreakField = this.getField(flagsClass, "BLOCK_BREAK");
            if (blockBreakField == null) {
                this.plugin.getLogger().warning("Could not find BLOCK_BREAK field in Flags");
                return true;
            }
            Object blockBreakFlag = blockBreakField.get(null);
            if (blockBreakFlag == null) {
                this.plugin.getLogger().warning("BLOCK_BREAK flag is null");
                return true;
            }
            Method hasRoleFlagMethod = this.getMethod(landWorld.getClass(), "hasRoleFlag", landPlayer.getClass(), Location.class, blockBreakFlag.getClass(), Material.class, Boolean.TYPE);
            if (hasRoleFlagMethod != null) {
                boolean hasFlag = (Boolean)hasRoleFlagMethod.invoke(landWorld, landPlayer, block.getLocation(), blockBreakFlag, block.getType(), false);
                this.plugin.getLogger().log(Level.FINE, "Land BLOCK_BREAK flag check for " + this.getPlayerNameFromLandPlayer(landPlayer) + ": " + hasFlag);
                return hasFlag;
            }
            hasRoleFlagMethod = this.getMethod(landWorld.getClass(), "hasRoleFlag", landPlayer.getClass(), Location.class, blockBreakFlag.getClass(), Boolean.TYPE);
            if (hasRoleFlagMethod != null) {
                boolean hasFlag = (Boolean)hasRoleFlagMethod.invoke(landWorld, landPlayer, block.getLocation(), blockBreakFlag, false);
                this.plugin.getLogger().log(Level.FINE, "Land BLOCK_BREAK flag check (no material) for " + this.getPlayerNameFromLandPlayer(landPlayer) + ": " + hasFlag);
                return hasFlag;
            }
            this.plugin.getLogger().warning("Could not find suitable hasRoleFlag method for claimed land");
            return false;
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Error checking land permissions", e);
            return false;
        }
    }

    private boolean checkWildernessPermission(Object landWorld, Object landPlayer, Block block) {
        try {
            if (this.hasWildernessBypassPermission(landPlayer)) {
                return true;
            }
            Class<?> flagsClass = this.getClass("me.angeschossen.lands.api.flags.type.Flags");
            if (flagsClass == null) {
                this.plugin.getLogger().warning("Could not find Flags class");
                return true;
            }
            Field blockBreakField = this.getField(flagsClass, "BLOCK_BREAK");
            if (blockBreakField == null) {
                this.plugin.getLogger().warning("Could not find BLOCK_BREAK field in Flags");
                return true;
            }
            Object blockBreakFlag = blockBreakField.get(null);
            if (blockBreakFlag == null) {
                this.plugin.getLogger().warning("BLOCK_BREAK flag is null");
                return true;
            }
            Method hasWildernessRoleFlagMethod = this.getMethod(landWorld.getClass(), "hasWildernessRoleFlag", landPlayer.getClass(), Location.class, blockBreakFlag.getClass(), Boolean.TYPE);
            if (hasWildernessRoleFlagMethod == null) {
                return true;
            }
            boolean hasFlag = (Boolean)hasWildernessRoleFlagMethod.invoke(landWorld, landPlayer, block.getLocation(), blockBreakFlag, false);
            this.plugin.getLogger().log(Level.FINE, "Wilderness BLOCK_BREAK flag check for " + this.getPlayerNameFromLandPlayer(landPlayer) + ": " + hasFlag);
            return hasFlag;
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Error checking wilderness permissions", e);
            return false;
        }
    }

    private boolean hasWildernessBypassPermission(Object landPlayer) {
        try {
            Method getPlayerMethod = this.getMethod(landPlayer.getClass(), "getPlayer", new Class[0]);
            if (getPlayerMethod == null) {
                return false;
            }
            Object playerObj = getPlayerMethod.invoke(landPlayer, new Object[0]);
            if (!(playerObj instanceof Player)) {
                return false;
            }
            Player player = (Player)playerObj;
            return player.hasPermission("lands.bypass.wilderness") || player.hasPermission("lands.wilderness.edit") || player.hasPermission("lands.wilderness.block.break") || player.hasPermission("lands.bypass.wilderness.block_break") || player.hasPermission("lands.bypass.wilderness.BLOCK_BREAK");
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Error checking wilderness bypass permissions", e);
            return false;
        }
    }

    private String getPlayerNameFromLandPlayer(Object landPlayer) {
        try {
            Object name;
            Object playerObj;
            Method getPlayerMethod = this.getMethod(landPlayer.getClass(), "getPlayer", new Class[0]);
            if (getPlayerMethod != null && (playerObj = getPlayerMethod.invoke(landPlayer, new Object[0])) instanceof Player) {
                return ((Player)playerObj).getName();
            }
            Method getNameMethod = this.getMethod(landPlayer.getClass(), "getName", new Class[0]);
            if (getNameMethod != null && (name = getNameMethod.invoke(landPlayer, new Object[0])) instanceof String) {
                return (String)name;
            }
        }
        catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Error getting player name from LandPlayer", e);
        }
        return "Unknown";
    }

    @Override
    public boolean isEnabled() {
        return this.landsPlugin != null && this.landsPlugin.isEnabled();
    }
}

