/*
 * Decompiled with CFR.
 */
package net.rwee.drill.recipe;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.DrillUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class RecipeManager {
    private final DrillPickaxePlugin plugin;
    private FileConfiguration recipesConfig;
    private File recipesFile;
    private final List<NamespacedKey> registeredRecipes;
    private final List<String> duplicateDrills;

    public RecipeManager(DrillPickaxePlugin plugin) {
        this.plugin = plugin;
        this.registeredRecipes = new ArrayList<NamespacedKey>();
        this.duplicateDrills = new ArrayList<String>();
        this.loadRecipesConfig();
    }

    private void loadRecipesConfig() {
        this.recipesFile = new File(this.plugin.getDataFolder(), "recipes.yml");
        if (!this.recipesFile.exists()) {
            this.plugin.saveResource("recipes.yml", false);
        }
        this.recipesConfig = YamlConfiguration.loadConfiguration(this.recipesFile);
        InputStream defConfigStream = this.plugin.getResource("recipes.yml");
        if (defConfigStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defConfigStream));
            this.recipesConfig.setDefaults(defConfig);
        }
    }

    public void reloadRecipes() {
        this.unregisterAllRecipes();
        this.duplicateDrills.clear();
        this.recipesConfig = YamlConfiguration.loadConfiguration(this.recipesFile);
        this.registerAllRecipes();
    }

    public void registerAllRecipes() {
        boolean multimode = this.plugin.getConfig().getBoolean("multimode", false);
        this.duplicateDrills.clear();
        if (!this.recipesConfig.getBoolean("recipes.enabled", true)) {
            return;
        }
        ArrayList<String> usedPatterns = new ArrayList<String>();
        if (multimode) {
            Set<String> drillTypes = DrillUtils.getAvailableDrillNames();
            if (drillTypes.isEmpty()) {
                this.plugin.getLogger().warning("Multimode is enabled but no drill types found in config.yml!");
                return;
            }
            this.checkOrphanedRecipes(drillTypes);
            int registeredCount = 0;
            int missingCount = 0;
            for (String drillType : drillTypes) {
                if (this.registerDrillRecipe(drillType, usedPatterns)) {
                    ++registeredCount;
                    continue;
                }
                ++missingCount;
            }
            this.plugin.getLogger().info("Registered " + registeredCount + " drill recipe(s) in multimode");
            if (missingCount > 0) {
                this.plugin.getLogger().warning(missingCount + " drill(s) have no crafting recipe defined in recipes.yml");
                this.plugin.getLogger().warning("Players will NOT be able to craft these drills. Add recipes or use /drill give command.");
            }
        } else if (this.registerDrillRecipe("legacy", usedPatterns)) {
            this.plugin.getLogger().info("Registered legacy drill recipe");
        } else {
            this.plugin.getLogger().warning("No recipe found for legacy drill in recipes.yml");
            this.plugin.getLogger().warning("Players cannot craft the drill. Use /drill give command or add recipe.");
        }
    }

    private void checkOrphanedRecipes(Set<String> validDrillTypes) {
        if (!this.recipesConfig.contains("recipes.drills")) {
            return;
        }
        ConfigurationSection drillsSection = this.recipesConfig.getConfigurationSection("recipes.drills");
        if (drillsSection == null) {
            return;
        }
        Set<String> recipeKeys = drillsSection.getKeys(false);
        ArrayList<String> orphanedRecipes = new ArrayList<String>();
        for (String recipeKey : recipeKeys) {
            if (recipeKey.equals("legacy-drill") || validDrillTypes.contains(recipeKey)) continue;
            orphanedRecipes.add(recipeKey);
        }
        if (!orphanedRecipes.isEmpty()) {
            this.plugin.getLogger().warning("Found " + orphanedRecipes.size() + " orphaned recipe(s) in recipes.yml:");
            for (String orphaned : orphanedRecipes) {
                this.plugin.getLogger().warning("  - '" + orphaned + "' has a recipe but no drill definition in config.yml");
            }
            this.plugin.getLogger().warning("These recipes will be IGNORED. Add corresponding drills to config.yml or remove from recipes.yml");
        }
    }

    private boolean registerDrillRecipe(String drillType, List<String> usedPatterns) {
        String recipeKey;
        String string = recipeKey = drillType.equals("legacy") ? "legacy-drill" : drillType;
        if (!this.recipesConfig.contains("recipes.drills." + recipeKey)) {
            this.plugin.getLogger().warning("No recipe found for drill type: '" + drillType + "'");
            return false;
        }
        ConfigurationSection recipeSection = this.recipesConfig.getConfigurationSection("recipes.drills." + recipeKey);
        if (recipeSection == null) {
            this.plugin.getLogger().warning("Invalid recipe configuration for: " + drillType);
            return false;
        }
        if (!recipeSection.getBoolean("enabled", true)) {
            this.plugin.getLogger().info("Recipe for '" + drillType + "' is disabled");
            return false;
        }
        if (!recipeSection.contains("shape")) {
            this.plugin.getLogger().warning("Recipe for '" + drillType + "' is missing 'shape' field");
            return false;
        }
        if (!recipeSection.contains("ingredients")) {
            this.plugin.getLogger().warning("Recipe for '" + drillType + "' is missing 'ingredients' field");
            return false;
        }
        try {
            ItemStack drillItem;
            ItemStack itemStack = drillItem = drillType.equals("legacy") ? DrillUtils.createDrillPickaxe() : DrillUtils.createDrillPickaxe(drillType);
            if (drillItem == null) {
                this.plugin.getLogger().warning("Failed to create drill item for: " + drillType);
                return false;
            }
            NamespacedKey key = new NamespacedKey(this.plugin, "drill_" + recipeKey);
            ShapedRecipe recipe = new ShapedRecipe(key, drillItem);
            List<String> shape = recipeSection.getStringList("shape");
            if (shape.size() != 3) {
                this.plugin.getLogger().warning("Recipe shape for '" + drillType + "' must have exactly 3 rows!");
                return false;
            }
            boolean hasContent = false;
            for (String row : shape) {
                if (row == null || row.trim().isEmpty() || row.replace(" ", "").isEmpty()) continue;
                hasContent = true;
                break;
            }
            if (!hasContent) {
                this.plugin.getLogger().warning("Recipe shape for '" + drillType + "' is empty");
                return false;
            }
            ConfigurationSection ingredientsSection = recipeSection.getConfigurationSection("ingredients");
            if (ingredientsSection == null) {
                this.plugin.getLogger().warning("No ingredients found for recipe: " + drillType);
                return false;
            }
            if (ingredientsSection.getKeys(false).isEmpty()) {
                this.plugin.getLogger().warning("Recipe for '" + drillType + "' has no ingredients defined");
                return false;
            }
            StringBuilder patternSignature = new StringBuilder();
            patternSignature.append(String.join((CharSequence)"|", shape)).append(":");
            ArrayList<CallSite> ingredientsList = new ArrayList<CallSite>();
            for (String key_char : ingredientsSection.getKeys(false)) {
                String materialName = ingredientsSection.getString(key_char);
                if (materialName.equalsIgnoreCase("AIR") || materialName.equalsIgnoreCase("EMPTY")) continue;
                ingredientsList.add((CallSite)((Object)(key_char + "=" + materialName.toUpperCase())));
            }
            ingredientsList.sort(String::compareTo);
            patternSignature.append(String.join((CharSequence)",", ingredientsList));
            String pattern = patternSignature.toString();
            if (usedPatterns.contains(pattern)) {
                this.plugin.getLogger().severe("========================================================");
                this.plugin.getLogger().severe("  DUPLICATE RECIPE DETECTED!");
                this.plugin.getLogger().severe("========================================================");
                this.plugin.getLogger().severe("  Drill: '" + drillType + "'");
                this.plugin.getLogger().severe("  This recipe is IDENTICAL to another drill's recipe!");
                this.plugin.getLogger().severe("");
                this.plugin.getLogger().severe("  Change the recipe in recipes.yml");
                this.plugin.getLogger().severe("========================================================");
                this.duplicateDrills.add(drillType);
                return false;
            }
            usedPatterns.add(pattern);
            recipe.shape(shape.get(0), shape.get(1), shape.get(2));
            for (String key_char : ingredientsSection.getKeys(false)) {
                if (key_char.length() != 1) {
                    this.plugin.getLogger().warning("Invalid ingredient key '" + key_char + "' - must be single character");
                    continue;
                }
                String materialName = ingredientsSection.getString(key_char);
                if (materialName.equalsIgnoreCase("AIR") || materialName.equalsIgnoreCase("EMPTY")) continue;
                try {
                    Material material = Material.valueOf(materialName.toUpperCase());
                    recipe.setIngredient(key_char.charAt(0), material);
                }
                catch (IllegalArgumentException e) {
                    this.plugin.getLogger().warning("Invalid material '" + materialName + "' in recipe for: " + drillType);
                    return false;
                }
            }
            Bukkit.addRecipe(recipe);
            this.registeredRecipes.add(key);
            this.plugin.getLogger().info("Successfully registered recipe for: " + drillType);
            return true;
        }
        catch (Exception e) {
            this.plugin.getLogger().severe("Error registering recipe for '" + drillType + "': " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public void unregisterAllRecipes() {
        for (NamespacedKey key : this.registeredRecipes) {
            Bukkit.removeRecipe(key);
        }
        this.registeredRecipes.clear();
    }

    public FileConfiguration getRecipesConfig() {
        return this.recipesConfig;
    }

    public List<String> getDuplicateDrills() {
        return new ArrayList<String>(this.duplicateDrills);
    }

    public void saveRecipes() {
        try {
            this.recipesConfig.save(this.recipesFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().severe("Could not save recipes.yml: " + e.getMessage());
        }
    }
}

