/*
 * Decompiled with CFR.
 */
package org.json;

import org.json.ParserConfiguration;

public class JSONParserConfiguration
extends ParserConfiguration {
    @Override
    protected JSONParserConfiguration clone() {
        return new JSONParserConfiguration();
    }

    public JSONParserConfiguration withMaxNestingDepth(int maxNestingDepth) {
        return (JSONParserConfiguration)super.withMaxNestingDepth(maxNestingDepth);
    }
}

