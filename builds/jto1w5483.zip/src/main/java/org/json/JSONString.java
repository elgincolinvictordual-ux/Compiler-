/*
 * Decompiled with CFR.
 */
package org.json;

public interface JSONString {
    public String toJSONString();
}

