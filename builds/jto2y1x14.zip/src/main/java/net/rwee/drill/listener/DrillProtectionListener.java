/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.PrepareAnvilEvent
 *  org.bukkit.event.inventory.PrepareSmithingEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.EnchantmentStorageMeta
 */
package net.rwee.drill.listener;

import java.util.List;
import java.util.Map;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.DrillUtils;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;

public class DrillProtectionListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onSmithingPrepare(PrepareSmithingEvent event) {
        ItemStack[] contents;
        for (ItemStack item : contents = event.getInventory().getContents()) {
            if (item == null || !DrillUtils.isDrillPickaxe(item)) continue;
            event.setResult(null);
            if (event.getView().getPlayer() instanceof Player) {
                Player player = (Player)event.getView().getPlayer();
                DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "cannot-upgrade");
            }
            return;
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onAnvilPrepare(PrepareAnvilEvent event) {
        boolean secondIsDrill;
        ItemStack firstItem = event.getInventory().getItem(0);
        ItemStack secondItem = event.getInventory().getItem(1);
        boolean allowEnchanting = DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.allow-anvil-enchanting", true);
        boolean firstIsDrill = firstItem != null && DrillUtils.isDrillPickaxe(firstItem);
        boolean bl = secondIsDrill = secondItem != null && DrillUtils.isDrillPickaxe(secondItem);
        if (!firstIsDrill && !secondIsDrill) {
            return;
        }
        Player player = null;
        if (event.getView().getPlayer() instanceof Player) {
            player = (Player)event.getView().getPlayer();
        }
        if (firstIsDrill && secondIsDrill) {
            event.setResult(null);
            if (player != null) {
                DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "cannot-combine");
            }
            return;
        }
        if (firstIsDrill && secondItem != null && secondItem.getType().name().contains("PICKAXE")) {
            event.setResult(null);
            if (player != null) {
                DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "cannot-combine");
            }
            return;
        }
        if (!allowEnchanting && firstIsDrill) {
            event.setResult(null);
            if (player != null) {
                DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "cannot-enchant-anvil");
            }
            return;
        }
        if (firstIsDrill && secondItem != null && secondItem.getType() == Material.ENCHANTED_BOOK) {
            if (this.hasBlockedEnchantments(secondItem)) {
                event.setResult(null);
                if (player != null) {
                    DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "blocked-enchantment");
                }
                return;
            }
            return;
        }
        if (firstIsDrill && secondItem != null && allowEnchanting) {
            event.setResult(null);
            if (player != null) {
                DrillPickaxePlugin.getInstance().getMessageManager().sendMessage(player, "only-enchanted-books");
            }
        }
    }

    private boolean hasBlockedEnchantments(ItemStack book) {
        if (book == null || book.getType() != Material.ENCHANTED_BOOK) {
            return false;
        }
        List blockedEnchants = DrillPickaxePlugin.getInstance().getConfig().getStringList("drill.blocked-enchantments");
        if (blockedEnchants.isEmpty()) {
            return false;
        }
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta)book.getItemMeta();
        if (meta != null) {
            Map storedEnchants = meta.getStoredEnchants();
            for (Map.Entry entry : storedEnchants.entrySet()) {
                Enchantment enchant = (Enchantment)entry.getKey();
                int level = (Integer)entry.getValue();
                String enchantName = enchant.getKey().getKey().toLowerCase();
                for (String blockedEntry : blockedEnchants) {
                    String blockedLower = blockedEntry.toLowerCase().trim();
                    if (blockedLower.contains(":")) {
                        String[] parts = blockedLower.split(":");
                        String blockedName = parts[0].trim();
                        try {
                            int blockedLevel = Integer.parseInt(parts[1].trim());
                            if (!enchantName.equals(blockedName) || level < blockedLevel) continue;
                            return true;
                        }
                        catch (NumberFormatException e) {
                            DrillPickaxePlugin.getInstance().getLogger().warning("Invalid blocked enchantment format: " + blockedEntry);
                            continue;
                        }
                    }
                    if (!enchantName.equals(blockedLower)) continue;
                    return true;
                }
            }
        }
        return false;
    }
}

