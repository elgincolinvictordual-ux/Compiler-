/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  com.massivecraft.factions.Board
 *  com.massivecraft.factions.FLocation
 *  com.massivecraft.factions.FPlayer
 *  com.massivecraft.factions.FPlayers
 *  com.massivecraft.factions.Faction
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package net.rwee.drill.protection;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import net.rwee.drill.protection.LandProtectionHook;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class FactionsUUIDHook
implements LandProtectionHook {
    private final boolean enabled;

    public FactionsUUIDHook(Plugin plugin) {
        boolean pluginEnabled = false;
        try {
            pluginEnabled = plugin.getServer().getPluginManager().isPluginEnabled("Factions");
        }
        catch (Exception e) {
            plugin.getLogger().warning("Error initializing Factions hook: " + e.toString());
        }
        this.enabled = pluginEnabled;
    }

    @Override
    public boolean canBreak(Player player, Block block) {
        if (!this.enabled) {
            return true;
        }
        FPlayer fPlayer = FPlayers.getInstance().getByPlayer(player);
        FLocation location = new FLocation(block.getLocation());
        Faction factionAtBlock = Board.getInstance().getFactionAt(location);
        if (factionAtBlock == null || factionAtBlock.isWilderness()) {
            return true;
        }
        Faction playerFaction = fPlayer.getFaction();
        return factionAtBlock.equals((Object)playerFaction);
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}

