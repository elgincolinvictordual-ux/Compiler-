/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.util.Vector
 */
package net.rwee.drill.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.rwee.drill.utils.ColorFormater;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class DrillUtils {
    private static JavaPlugin plugin;

    public static void init(JavaPlugin main) {
        plugin = main;
    }

    public static boolean isDrillPickaxe(ItemStack item) {
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
            return false;
        }
        FileConfiguration config = plugin.getConfig();
        boolean multimode = config.getBoolean("multimode", false);
        String itemDisplayName = item.getItemMeta().getDisplayName();
        if (multimode) {
            ConfigurationSection drillSection = config.getConfigurationSection("drill-pickaxes");
            if (drillSection != null) {
                for (String drillName : drillSection.getKeys(false)) {
                    ConfigurationSection drill = drillSection.getConfigurationSection(drillName);
                    if (drill == null) continue;
                    String expectedName = ColorFormater.hex(drill.getString("name", "&6Drill Pickaxe"));
                    Material expectedType = Material.getMaterial((String)drill.getString("type", "DIAMOND_PICKAXE"));
                    if (item.getType() != expectedType || !DrillUtils.compareColoredNames(itemDisplayName, expectedName)) continue;
                    return true;
                }
            }
            return false;
        }
        String expectedName = ColorFormater.hex(config.getString("drill-pickaxe.name", "&6Drill Pickaxe"));
        Material expectedType = Material.getMaterial((String)config.getString("drill-pickaxe.type", "DIAMOND_PICKAXE"));
        return item.getType() == expectedType && DrillUtils.compareColoredNames(itemDisplayName, expectedName);
    }

    private static boolean compareColoredNames(String name1, String name2) {
        if (name1 == null || name2 == null) {
            return false;
        }
        if (name1.equals(name2)) {
            return true;
        }
        String plain1 = ChatColor.stripColor((String)name1);
        String plain2 = ChatColor.stripColor((String)name2);
        return plain1 != null && plain1.equals(plain2);
    }

    public static String getDrillType(ItemStack item) {
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
            return null;
        }
        FileConfiguration config = plugin.getConfig();
        boolean multimode = config.getBoolean("multimode", false);
        String itemDisplayName = item.getItemMeta().getDisplayName();
        if (multimode) {
            ConfigurationSection drillSection = config.getConfigurationSection("drill-pickaxes");
            if (drillSection != null) {
                for (String drillName : drillSection.getKeys(false)) {
                    ConfigurationSection drill = drillSection.getConfigurationSection(drillName);
                    if (drill == null) continue;
                    String expectedName = ColorFormater.hex(drill.getString("name", "&6Drill Pickaxe"));
                    Material expectedType = Material.getMaterial((String)drill.getString("type", "DIAMOND_PICKAXE"));
                    if (item.getType() != expectedType || !DrillUtils.compareColoredNames(itemDisplayName, expectedName)) continue;
                    return drillName;
                }
            }
            return null;
        }
        String expectedName = ColorFormater.hex(config.getString("drill-pickaxe.name", "&6Drill Pickaxe"));
        Material expectedType = Material.getMaterial((String)config.getString("drill-pickaxe.type", "DIAMOND_PICKAXE"));
        if (item.getType() == expectedType && DrillUtils.compareColoredNames(itemDisplayName, expectedName)) {
            return "legacy";
        }
        return null;
    }

    public static int getDrillRadius(String drillType) {
        ConfigurationSection drillSection;
        FileConfiguration config = plugin.getConfig();
        boolean multimode = config.getBoolean("multimode", false);
        if (multimode && !drillType.equals("legacy") && (drillSection = config.getConfigurationSection("drill-pickaxes." + drillType)) != null) {
            return drillSection.getInt("radius", config.getInt("drill-pickaxe.radius", 1));
        }
        return config.getInt("drill-pickaxe.radius", 1);
    }

    public static ItemStack createDrillPickaxe() {
        FileConfiguration config = plugin.getConfig();
        return DrillUtils.createDrillPickaxeFromConfig("drill-pickaxe", config);
    }

    public static ItemStack createDrillPickaxe(String drillName) {
        FileConfiguration config = plugin.getConfig();
        boolean multimode = config.getBoolean("multimode", false);
        if (multimode) {
            ConfigurationSection drillSection = config.getConfigurationSection("drill-pickaxes." + drillName);
            if (drillSection == null) {
                plugin.getLogger().warning("Drill type '" + drillName + "' not found in config!");
                return null;
            }
            return DrillUtils.createDrillPickaxeFromSection(drillSection, config);
        }
        return DrillUtils.createDrillPickaxe();
    }

    public static Set<String> getAvailableDrillNames() {
        ConfigurationSection drillSection;
        FileConfiguration config = plugin.getConfig();
        boolean multimode = config.getBoolean("multimode", false);
        if (multimode && (drillSection = config.getConfigurationSection("drill-pickaxes")) != null) {
            return drillSection.getKeys(false);
        }
        return new HashSet<String>();
    }

    private static ItemStack createDrillPickaxeFromConfig(String path, FileConfiguration config) {
        Material type = Material.getMaterial((String)config.getString(path + ".type", "DIAMOND_PICKAXE"));
        String name = ColorFormater.hex(config.getString(path + ".name", "&6Drill Pickaxe"));
        List lore = config.getStringList(path + ".lore").stream().map(ColorFormater::hex).collect(Collectors.toList());
        ItemStack item = new ItemStack(type);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        boolean durabilityLossEnabled = config.getBoolean("drill.durability-loss", true);
        if (!durabilityLossEnabled) {
            meta.setUnbreakable(true);
        }
        DrillUtils.applyEnchantments(meta, config, path);
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack createDrillPickaxeFromSection(ConfigurationSection section, FileConfiguration config) {
        Material type = Material.getMaterial((String)section.getString("type", "DIAMOND_PICKAXE"));
        String name = ColorFormater.hex(section.getString("name", "&6Drill Pickaxe"));
        List lore = section.getStringList("lore").stream().map(ColorFormater::hex).collect(Collectors.toList());
        ItemStack item = new ItemStack(type);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        boolean durabilityLossEnabled = config.getBoolean("drill.durability-loss", true);
        if (!durabilityLossEnabled) {
            meta.setUnbreakable(true);
        }
        DrillUtils.applyEnchantmentsFromSection(meta, section);
        item.setItemMeta(meta);
        return item;
    }

    private static void applyEnchantments(ItemMeta meta, FileConfiguration config, String path) {
        if (config.contains(path + ".enchantments")) {
            Map enchantments = config.getConfigurationSection(path + ".enchantments").getValues(false);
            for (String enchantmentName : enchantments.keySet()) {
                try {
                    Enchantment enchantment = Enchantment.getByKey((NamespacedKey)NamespacedKey.minecraft((String)enchantmentName.toLowerCase()));
                    if (enchantment != null) {
                        int level = (Integer)enchantments.get(enchantmentName);
                        meta.addEnchant(enchantment, level, true);
                        continue;
                    }
                    plugin.getLogger().warning("Invalid enchantment name in config: " + enchantmentName);
                }
                catch (Exception e) {
                    plugin.getLogger().warning("Error applying enchantment: " + enchantmentName + " - " + e.getMessage());
                }
            }
        }
    }

    private static void applyEnchantmentsFromSection(ItemMeta meta, ConfigurationSection section) {
        ConfigurationSection enchSection;
        if (section.contains("enchantments") && (enchSection = section.getConfigurationSection("enchantments")) != null) {
            Map enchantments = enchSection.getValues(false);
            for (String enchantmentName : enchantments.keySet()) {
                try {
                    Enchantment enchantment = Enchantment.getByKey((NamespacedKey)NamespacedKey.minecraft((String)enchantmentName.toLowerCase()));
                    if (enchantment != null) {
                        int level = (Integer)enchantments.get(enchantmentName);
                        meta.addEnchant(enchantment, level, true);
                        continue;
                    }
                    plugin.getLogger().warning("Invalid enchantment name in config: " + enchantmentName);
                }
                catch (Exception e) {
                    plugin.getLogger().warning("Error applying enchantment: " + enchantmentName + " - " + e.getMessage());
                }
            }
        }
    }

    public static List<Block> getDrillBlocks(Block center, Player player) {
        ArrayList<Block> blocks = new ArrayList<Block>();
        ItemStack tool = player.getInventory().getItemInMainHand();
        String drillType = DrillUtils.getDrillType(tool);
        int radius = DrillUtils.getDrillRadius(drillType);
        if (radius == 1) {
            Vector direction = player.getLocation().getDirection();
            double absX = Math.abs(direction.getX());
            double absY = Math.abs(direction.getY());
            double absZ = Math.abs(direction.getZ());
            if (absY > absX && absY > absZ) {
                for (int x = -1; x <= 1; ++x) {
                    for (int z = -1; z <= 1; ++z) {
                        Block relative = center.getRelative(x, 0, z);
                        if (relative.getType() == Material.BEDROCK) continue;
                        blocks.add(relative);
                    }
                }
            } else if (absX > absZ) {
                for (int y = -1; y <= 1; ++y) {
                    for (int z = -1; z <= 1; ++z) {
                        Block relative = center.getRelative(0, y, z);
                        if (relative.getType() == Material.BEDROCK) continue;
                        blocks.add(relative);
                    }
                }
            } else {
                for (int x = -1; x <= 1; ++x) {
                    for (int y = -1; y <= 1; ++y) {
                        Block relative = center.getRelative(x, y, 0);
                        if (relative.getType() == Material.BEDROCK) continue;
                        blocks.add(relative);
                    }
                }
            }
        } else if (radius == 2) {
            for (int x = -1; x <= 1; ++x) {
                for (int y = -1; y <= 1; ++y) {
                    for (int z = -1; z <= 1; ++z) {
                        Block relative = center.getRelative(x, y, z);
                        if (relative.getType() == Material.BEDROCK) continue;
                        blocks.add(relative);
                    }
                }
            }
        } else {
            int cubeSize = radius + 1;
            int range = cubeSize / 2;
            for (int x = -range; x <= range; ++x) {
                for (int y = -range; y <= range; ++y) {
                    for (int z = -range; z <= range; ++z) {
                        Block relative = center.getRelative(x, y, z);
                        if (relative.getType() == Material.BEDROCK) continue;
                        blocks.add(relative);
                    }
                }
            }
        }
        return blocks;
    }

    public static void updateDrillPickaxeUnbreakable(ItemStack item) {
        if (!DrillUtils.isDrillPickaxe(item)) {
            return;
        }
        FileConfiguration config = plugin.getConfig();
        boolean durabilityLossEnabled = config.getBoolean("drill.durability-loss", true);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setUnbreakable(!durabilityLossEnabled);
            item.setItemMeta(meta);
        }
    }
}

