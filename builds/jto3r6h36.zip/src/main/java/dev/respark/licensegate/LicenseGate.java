/*
 * Decompiled with CFR.
 */
package dev.respark.licensegate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import org.json.JSONObject;

public class LicenseGate {
    private static final String DEFAULT_SERVER = "https://api.licensegate.io";
    private String userId;
    private String publicRsaKey;
    private String validationServer = "https://api.licensegate.io";
    private boolean useChallenges = false;
    private boolean debug = false;

    public LicenseGate(String userId) {
        this.userId = userId;
    }

    public LicenseGate(String userId, String publicRsaKey) {
        this.userId = userId;
        this.publicRsaKey = publicRsaKey;
        this.useChallenges = true;
    }

    public LicenseGate setPublicRsaKey(String publicRsaKey) {
        this.publicRsaKey = publicRsaKey;
        return this;
    }

    public LicenseGate setValidationServer(String validationServer) {
        this.validationServer = validationServer;
        return this;
    }

    public LicenseGate useChallenges() {
        this.useChallenges = true;
        return this;
    }

    public LicenseGate debug() {
        this.debug = true;
        return this;
    }

    public ValidationType verify(String licenseKey) {
        return this.verify(licenseKey, null, null);
    }

    public ValidationType verify(String licenseKey, String scope) {
        return this.verify(licenseKey, scope, null);
    }

    public ValidationType verify(String licenseKey, String scope, String metadata) {
        try {
            String challenge = this.useChallenges ? String.valueOf(System.currentTimeMillis()) : null;
            JSONObject response = this.requestServer(this.buildUrl(licenseKey, scope, metadata, challenge));
            if (response.has("error") || !response.has("result")) {
                if (this.debug) {
                    System.out.println("Error: " + response.getString("error"));
                }
                return ValidationType.SERVER_ERROR;
            }
            if (response.has("valid") && !response.getBoolean("valid")) {
                ValidationType result = ValidationType.valueOf(response.getString("result"));
                if (result == ValidationType.VALID) {
                    return ValidationType.SERVER_ERROR;
                }
                return result;
            }
            if (this.useChallenges) {
                if (!response.has("signedChallenge")) {
                    if (this.debug) {
                        System.out.println("Error: No challenge result");
                    }
                    return ValidationType.FAILED_CHALLENGE;
                }
                if (!this.verifyChallenge(challenge, response.getString("signedChallenge"))) {
                    if (this.debug) {
                        System.out.println("Error: Challenge verification failed");
                    }
                    return ValidationType.FAILED_CHALLENGE;
                }
            }
            return ValidationType.valueOf(response.getString("result"));
        }
        catch (IOException e) {
            if (this.debug) {
                e.printStackTrace();
            }
            return ValidationType.CONNECTION_ERROR;
        }
    }

    public boolean verifySimple(String licenseKey) {
        return this.verify(licenseKey) == ValidationType.VALID;
    }

    public boolean verifySimple(String licenseKey, String scope) {
        return this.verify(licenseKey, scope) == ValidationType.VALID;
    }

    public boolean verifySimple(String licenseKey, String scope, String metadata) {
        return this.verify(licenseKey, scope, metadata) == ValidationType.VALID;
    }

    private String buildUrl(String licenseKey, String scope, String metadata, String challenge) throws UnsupportedEncodingException {
        String queryString = "";
        if (metadata != null) {
            queryString = queryString + "?metadata=" + URLEncoder.encode(metadata, StandardCharsets.UTF_8.name());
        }
        if (scope != null) {
            queryString = queryString + (queryString.isEmpty() ? "?" : "&") + "scope=" + URLEncoder.encode(scope, StandardCharsets.UTF_8.name());
        }
        if (this.useChallenges && challenge != null) {
            queryString = queryString + (queryString.isEmpty() ? "?" : "&") + "challenge=" + URLEncoder.encode(challenge, StandardCharsets.UTF_8.name());
        }
        return this.validationServer + "/license/" + this.userId + "/" + licenseKey + "/verify" + queryString;
    }

    private JSONObject requestServer(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection)url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        con.setDoOutput(true);
        int responseCode = con.getResponseCode();
        if (this.debug) {
            System.out.println("\nSending request to URL : " + url);
            System.out.println("Response Code : " + responseCode);
        }
        try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));){
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            String jsonStr = response.toString();
            if (this.debug) {
                System.out.println("Response: " + jsonStr);
            }
            JSONObject jSONObject = new JSONObject(jsonStr);
            return jSONObject;
        }
    }

    private boolean verifyChallenge(String challenge, String signedChallengeBase64) {
        try {
            String pemHeader = "-----BEGIN PUBLIC KEY-----";
            String pemFooter = "-----END PUBLIC KEY-----";
            String base64PublicKey = this.publicRsaKey.replace(pemHeader, "").replace(pemFooter, "").replaceAll("\\s+", "");
            byte[] publicKeyBytes = Base64.getDecoder().decode(base64PublicKey);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = keyFactory.generatePublic(keySpec);
            byte[] signatureBytes = Base64.getDecoder().decode(signedChallengeBase64);
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initVerify(publicKey);
            signature.update(challenge.getBytes());
            return signature.verify(signatureBytes);
        }
        catch (Exception e) {
            if (this.debug) {
                e.printStackTrace();
            }
            return false;
        }
    }

    public static enum ValidationType {
        VALID(true),
        NOT_FOUND,
        NOT_ACTIVE,
        EXPIRED,
        LICENSE_SCOPE_FAILED,
        IP_LIMIT_EXCEEDED,
        RATE_LIMIT_EXCEEDED,
        FAILED_CHALLENGE,
        SERVER_ERROR,
        CONNECTION_ERROR;

        private boolean valid;

        private ValidationType(boolean valid) {
            this.valid = valid;
        }

        private ValidationType() {
            this(false);
        }

        public boolean isValid() {
            return this.valid;
        }
    }
}

