/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package net.rwee.drill.command;

import java.util.List;
import java.util.Set;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.DrillUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class DrillCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("drill.use")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You do not have permission to use this command.");
            return true;
        }
        if (args.length == 0) {
            this.sendUsageMessage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give": {
                return this.handleGiveCommand(sender, args);
            }
            case "reload": {
                return this.handleReloadCommand(sender, args);
            }
            case "check": 
            case "verify": {
                return this.handleCheckCommand(sender);
            }
        }
        sender.sendMessage(String.valueOf(ChatColor.RED) + "Unknown subcommand. Use " + String.valueOf(ChatColor.GOLD) + "give" + String.valueOf(ChatColor.RED) + ", " + String.valueOf(ChatColor.GOLD) + "reload" + String.valueOf(ChatColor.RED) + ", or " + String.valueOf(ChatColor.GOLD) + "check" + String.valueOf(ChatColor.RED) + ".");
        return true;
    }

    private void sendUsageMessage(CommandSender sender) {
        boolean multimode = DrillPickaxePlugin.getInstance().getConfig().getBoolean("multimode", false);
        sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "========== " + String.valueOf(ChatColor.GOLD) + "DonutDrillX Commands" + String.valueOf(ChatColor.YELLOW) + " ==========");
        if (multimode) {
            sender.sendMessage(String.valueOf(ChatColor.GOLD) + "/drill give <player> <drill_type>" + String.valueOf(ChatColor.GRAY) + " - Give a drill to a player");
            sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Available types: " + String.valueOf(ChatColor.AQUA) + String.join((CharSequence)", ", DrillUtils.getAvailableDrillNames()));
        } else {
            sender.sendMessage(String.valueOf(ChatColor.GOLD) + "/drill give <player>" + String.valueOf(ChatColor.GRAY) + " - Give a drill to a player");
        }
        sender.sendMessage(String.valueOf(ChatColor.GOLD) + "/drill reload" + String.valueOf(ChatColor.GRAY) + " - Reload all configurations");
        sender.sendMessage(String.valueOf(ChatColor.GOLD) + "/drill check" + String.valueOf(ChatColor.GRAY) + " - Check drill/recipe sync status");
        sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "==========================================");
    }

    private boolean handleCheckCommand(CommandSender sender) {
        if (!sender.hasPermission("drill.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You do not have permission to use this command.");
            return true;
        }
        boolean multimode = DrillPickaxePlugin.getInstance().getConfig().getBoolean("multimode", false);
        boolean recipesEnabled = DrillPickaxePlugin.getInstance().getRecipeManager().getRecipesConfig().getBoolean("recipes.enabled", true);
        sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "========== " + String.valueOf(ChatColor.GOLD) + "Drill/Recipe Status" + String.valueOf(ChatColor.YELLOW) + " ==========");
        sender.sendMessage(String.valueOf(ChatColor.GRAY) + "Mode: " + (multimode ? String.valueOf(ChatColor.GREEN) + "Multimode" : String.valueOf(ChatColor.AQUA) + "Legacy"));
        sender.sendMessage(String.valueOf(ChatColor.GRAY) + "Recipes: " + (recipesEnabled ? String.valueOf(ChatColor.GREEN) + "Enabled" : String.valueOf(ChatColor.RED) + "Disabled"));
        sender.sendMessage("");
        if (!recipesEnabled) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "Recipes are globally disabled!");
            sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "==========================================");
            return true;
        }
        List<String> duplicateDrills = DrillPickaxePlugin.getInstance().getRecipeManager().getDuplicateDrills();
        if (!duplicateDrills.isEmpty()) {
            sender.sendMessage(String.valueOf(ChatColor.GOLD) + "Duplicate recipes found:");
            for (String duplicate : duplicateDrills) {
                sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "  " + duplicate);
            }
            sender.sendMessage("");
        }
        if (multimode) {
            Set<String> drillTypes = DrillUtils.getAvailableDrillNames();
            if (drillTypes.isEmpty()) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "No drills found in config.yml");
                return true;
            }
            int withRecipes = 0;
            int withoutRecipes = 0;
            for (String drillType : drillTypes) {
                boolean hasRecipe = DrillPickaxePlugin.getInstance().getRecipeManager().getRecipesConfig().contains("recipes.drills." + drillType);
                boolean isDuplicate = duplicateDrills.contains(drillType);
                if (isDuplicate) {
                    sender.sendMessage(String.valueOf(ChatColor.YELLOW) + drillType + String.valueOf(ChatColor.GRAY) + " - Duplicate recipe");
                    ++withoutRecipes;
                    continue;
                }
                if (hasRecipe) {
                    boolean recipeEnabled = DrillPickaxePlugin.getInstance().getRecipeManager().getRecipesConfig().getBoolean("recipes.drills." + drillType + ".enabled", true);
                    if (recipeEnabled && recipesEnabled) {
                        sender.sendMessage(String.valueOf(ChatColor.GREEN) + drillType + String.valueOf(ChatColor.GRAY) + " - Craftable");
                        ++withRecipes;
                        continue;
                    }
                    if (recipeEnabled && !recipesEnabled) {
                        sender.sendMessage(String.valueOf(ChatColor.YELLOW) + drillType + String.valueOf(ChatColor.GRAY) + " - Globally disabled");
                        ++withoutRecipes;
                        continue;
                    }
                    sender.sendMessage(String.valueOf(ChatColor.YELLOW) + drillType + String.valueOf(ChatColor.GRAY) + " - Disabled");
                    ++withoutRecipes;
                    continue;
                }
                sender.sendMessage(String.valueOf(ChatColor.RED) + drillType + String.valueOf(ChatColor.GRAY) + " - No recipe");
                ++withoutRecipes;
            }
            sender.sendMessage("");
            sender.sendMessage(String.valueOf(ChatColor.GRAY) + "Craftable: " + String.valueOf(ChatColor.GREEN) + withRecipes + String.valueOf(ChatColor.GRAY) + " | Not craftable: " + String.valueOf(ChatColor.RED) + withoutRecipes);
        } else {
            boolean hasRecipe = DrillPickaxePlugin.getInstance().getRecipeManager().getRecipesConfig().contains("recipes.drills.legacy-drill");
            if (hasRecipe) {
                boolean recipeEnabled = DrillPickaxePlugin.getInstance().getRecipeManager().getRecipesConfig().getBoolean("recipes.drills.legacy-drill.enabled", true);
                if (recipeEnabled && recipesEnabled) {
                    sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Legacy drill - Craftable");
                } else if (recipeEnabled && !recipesEnabled) {
                    sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Legacy drill - Globally disabled");
                } else {
                    sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Legacy drill - Disabled");
                }
            } else {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Legacy drill - No recipe");
            }
        }
        sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "==========================================");
        return true;
    }

    private boolean handleReloadCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("drill.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You do not have permission to use this command.");
            return true;
        }
        DrillPickaxePlugin.getInstance().reloadConfig();
        DrillPickaxePlugin.getInstance().getMessageManager().reloadMessages();
        DrillPickaxePlugin.getInstance().getRecipeManager().reloadRecipes();
        sender.sendMessage(String.valueOf(ChatColor.GREEN) + "DonutDrillX Configuration reloaded!");
        return true;
    }

    private boolean handleGiveCommand(CommandSender sender, String[] args) {
        boolean multimode = DrillPickaxePlugin.getInstance().getConfig().getBoolean("multimode", false);
        if (multimode) {
            if (args.length < 3) {
                sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Usage: " + String.valueOf(ChatColor.GOLD) + "/drill give <player> <drill_type>");
                sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Available drill types: " + String.valueOf(ChatColor.AQUA) + String.join((CharSequence)", ", DrillUtils.getAvailableDrillNames()));
                return true;
            }
            Player target = Bukkit.getPlayer((String)args[1]);
            if (target == null) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Player not found.");
                return true;
            }
            String drillType = args[2];
            if (!DrillUtils.getAvailableDrillNames().contains(drillType)) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Invalid drill type! Available types: " + String.valueOf(ChatColor.AQUA) + String.join((CharSequence)", ", DrillUtils.getAvailableDrillNames()));
                return true;
            }
            ItemStack drill = DrillUtils.createDrillPickaxe(drillType);
            if (drill == null) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Error creating drill pickaxe of type: " + drillType);
                return true;
            }
            target.getInventory().addItem(new ItemStack[]{drill});
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Drill Pickaxe (" + String.valueOf(ChatColor.AQUA) + drillType + String.valueOf(ChatColor.GREEN) + ") given to " + String.valueOf(ChatColor.AQUA) + target.getName());
        } else {
            if (args.length < 2) {
                sender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Usage: " + String.valueOf(ChatColor.GOLD) + "/drill give <player>");
                return true;
            }
            Player target = Bukkit.getPlayer((String)args[1]);
            if (target == null) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Player not found.");
                return true;
            }
            ItemStack drill = DrillUtils.createDrillPickaxe();
            target.getInventory().addItem(new ItemStack[]{drill});
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "DonutDrill given to " + String.valueOf(ChatColor.AQUA) + target.getName());
        }
        return true;
    }
}

