/*
 * Decompiled with CFR.
 */
package net.rwee.drill.lib.folialib.enums;

public enum EntityTaskResult {
    SUCCESS,
    ENTITY_RETIRED,
    SCHEDULER_RETIRED;

}

