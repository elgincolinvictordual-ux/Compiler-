/*
 * Decompiled with CFR.
 */
package net.rwee.drill.lib.folialib.impl;

import net.rwee.drill.lib.folialib.FoliaLib;
import net.rwee.drill.lib.folialib.impl.LegacySpigotImplementation;

public class LegacyPaperImplementation
extends LegacySpigotImplementation {
    public LegacyPaperImplementation(FoliaLib foliaLib) {
        super(foliaLib);
    }
}

