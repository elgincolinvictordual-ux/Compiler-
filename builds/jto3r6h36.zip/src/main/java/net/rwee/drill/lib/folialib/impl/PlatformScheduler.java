/*
 * Decompiled with CFR.
 */
package net.rwee.drill.lib.folialib.impl;

import net.rwee.drill.lib.folialib.impl.ServerImplementation;

public interface PlatformScheduler
extends ServerImplementation {
}

