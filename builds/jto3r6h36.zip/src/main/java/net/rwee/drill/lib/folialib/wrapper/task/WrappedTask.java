/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 */
package net.rwee.drill.lib.folialib.wrapper.task;

import org.bukkit.plugin.Plugin;

public interface WrappedTask {
    public void cancel();

    public boolean isCancelled();

    public Plugin getOwningPlugin();

    public boolean isAsync();
}

