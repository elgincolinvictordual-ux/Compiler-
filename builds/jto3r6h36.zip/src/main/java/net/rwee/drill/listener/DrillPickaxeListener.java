/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.bukkit.WorldGuardPlugin
 *  com.sk89q.worldguard.protection.ApplicableRegionSet
 *  com.sk89q.worldguard.protection.association.RegionAssociable
 *  com.sk89q.worldguard.protection.flags.Flags
 *  com.sk89q.worldguard.protection.flags.StateFlag
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.SoundCategory
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.ItemMeta
 */
package net.rwee.drill.listener;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.association.RegionAssociable;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.DrillUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

public class DrillPickaxeListener
implements Listener {
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!DrillUtils.isDrillPickaxe(tool)) {
            return;
        }
        if (!DrillPickaxePlugin.getInstance().getLicenseManager().quickCheck()) {
            return;
        }
        List disabledWorlds = DrillPickaxePlugin.getInstance().getConfig().getStringList("drill.disabled-worlds");
        if (disabledWorlds.contains(player.getWorld().getName())) {
            return;
        }
        Block center = event.getBlock();
        if (DrillPickaxePlugin.getInstance().getBlockedMaterials().contains(center.getType())) {
            return;
        }
        boolean useRegions = DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.use-regions", true);
        List allowedRegions = DrillPickaxePlugin.getInstance().getConfig().getStringList("drill.allowed-regions");
        boolean durabilityLossEnabled = DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.durability-loss");
        boolean enableSound = DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.enable-sound");
        String soundName = DrillPickaxePlugin.getInstance().getConfig().getString("drill.sound-type");
        List protectedBlocks = DrillPickaxePlugin.getInstance().getConfig().getStringList("drill.protected-blocks").stream().map(material -> {
            try {
                return Material.valueOf((String)material.toUpperCase());
            }
            catch (IllegalArgumentException e) {
                DrillPickaxePlugin.getInstance().getLogger().warning("[DonutDrillX] Invalid material in protected-blocks: " + material);
                return null;
            }
        }).filter(material -> material != null).collect(Collectors.toList());
        List<Block> blocks = DrillUtils.getDrillBlocks(center, player);
        for (Block block : blocks) {
            if (block.getType() == Material.BEDROCK || block.getType() == Material.BARRIER || DrillPickaxePlugin.getInstance().getBlockedMaterials().contains(block.getType()) || protectedBlocks.contains(block.getType()) || !DrillPickaxePlugin.getInstance().getProtectionManager().canBreak(player, block) || !this.canBuild(player, block) || useRegions && !this.isInAllowedRegionOrNone(block, allowedRegions)) continue;
            block.breakNaturally(tool);
            if (durabilityLossEnabled && !this.handleDurabilityLoss(tool, player)) break;
            if (!enableSound) continue;
            try {
                Sound sound = Sound.valueOf((String)soundName.toUpperCase());
                player.playSound(block.getLocation(), sound, SoundCategory.BLOCKS, 1.0f, 1.0f);
            }
            catch (IllegalArgumentException e) {
                DrillPickaxePlugin.getInstance().getLogger().warning("[DonutDrillX] Invalid sound in config: " + soundName);
            }
        }
    }

    private boolean handleDurabilityLoss(ItemStack tool, Player player) {
        short maxDurability;
        if (tool == null || !tool.hasItemMeta()) {
            return true;
        }
        ItemMeta meta = tool.getItemMeta();
        if (!(meta instanceof Damageable)) {
            return true;
        }
        Damageable damageable = (Damageable)meta;
        int currentDamage = damageable.getDamage();
        int newDamage = currentDamage + 1;
        if (newDamage >= (maxDurability = tool.getType().getMaxDurability())) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
            return false;
        }
        damageable.setDamage(newDamage);
        tool.setItemMeta(meta);
        return true;
    }

    private boolean isInAllowedRegionOrNone(Block block, List<String> allowedRegions) {
        if (!DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.use-regions", true)) {
            return true;
        }
        RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((World)block.getWorld()));
        if (manager == null) {
            return true;
        }
        BlockVector3 vec = BukkitAdapter.asBlockVector((Location)block.getLocation());
        Set<ProtectedRegion> regions = manager.getApplicableRegions(vec).getRegions();
        if (regions.isEmpty()) {
            return true;
        }
        for (ProtectedRegion region : regions) {
            if (!allowedRegions.contains(region.getId())) continue;
            return true;
        }
        return false;
    }

    private boolean canBuild(Player player, Block block) {
        if (!DrillPickaxePlugin.getInstance().getConfig().getBoolean("drill.use-regions", true)) {
            return true;
        }
        RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((World)block.getWorld()));
        if (manager == null) {
            return true;
        }
        ApplicableRegionSet regionSet = manager.getApplicableRegions(BukkitAdapter.asBlockVector((Location)block.getLocation()));
        return regionSet.testState((RegionAssociable)WorldGuardPlugin.inst().wrapPlayer(player), new StateFlag[]{Flags.BUILD});
    }
}

