/*
 * Decompiled with CFR.
 */
package net.rwee.drill.metrics.charts;

import java.util.concurrent.Callable;
import net.rwee.drill.metrics.charts.CustomChart;
import net.rwee.drill.metrics.json.JsonObjectBuilder;

public class SimplePie
extends CustomChart {
    private final Callable<String> callable;

    public SimplePie(String chartId, Callable<String> callable) {
        super(chartId);
        this.callable = callable;
    }

    @Override
    protected JsonObjectBuilder.JsonObject getChartData() throws Exception {
        String value = this.callable.call();
        if (value == null || value.isEmpty()) {
            return null;
        }
        return new JsonObjectBuilder().appendField("value", value).build();
    }
}

