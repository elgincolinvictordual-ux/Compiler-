package net.rwee.drill.protection;

import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * FactionsUUID hook. Uses reflection so the plugin builds without the Factions jar.
 */
public class FactionsUUIDHook
implements LandProtectionHook {
    private final boolean enabled;
    private final Plugin owner;
    private boolean failureLogged = false;

    public FactionsUUIDHook(Plugin plugin) {
        boolean pluginEnabled = false;
        try {
            pluginEnabled = plugin.getServer().getPluginManager().isPluginEnabled("Factions");
        }
        catch (Exception e) {
            plugin.getLogger().warning("Error initializing Factions hook: " + e.toString());
        }
        this.enabled = pluginEnabled;
        this.owner = plugin;
    }

    @Override
    public boolean canBreak(Player player, Block block) {
        if (!this.enabled) {
            return true;
        }
        try {
            Plugin factions = Bukkit.getPluginManager().getPlugin("Factions");
            ClassLoader cl = factions.getClass().getClassLoader();
            Class<?> fPlayersClass = Class.forName("com.massivecraft.factions.FPlayers", true, cl);
            Class<?> fLocationClass = Class.forName("com.massivecraft.factions.FLocation", true, cl);
            Class<?> boardClass = Class.forName("com.massivecraft.factions.Board", true, cl);

            Object fPlayers = fPlayersClass.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
            Object fPlayer = fPlayersClass.getMethod("getByPlayer", Player.class).invoke(fPlayers, player);
            Object location = fLocationClass.getConstructor(org.bukkit.Location.class).newInstance(block.getLocation());
            Object board = boardClass.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
            Method getFactionAt = null;
            for (Method m : boardClass.getMethods()) {
                if (m.getName().equals("getFactionAt") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isAssignableFrom(fLocationClass)) {
                    getFactionAt = m;
                    break;
                }
            }
            if (getFactionAt == null) {
                return true;
            }
            Object factionAtBlock = getFactionAt.invoke(board, location);
            if (factionAtBlock == null) {
                return true;
            }
            boolean wilderness = (Boolean)factionAtBlock.getClass().getMethod("isWilderness", new Class[0]).invoke(factionAtBlock, new Object[0]);
            if (wilderness) {
                return true;
            }
            Object playerFaction = fPlayer.getClass().getMethod("getFaction", new Class[0]).invoke(fPlayer, new Object[0]);
            return factionAtBlock.equals(playerFaction);
        }
        catch (Throwable t) {
            if (!this.failureLogged) {
                this.failureLogged = true;
                this.owner.getLogger().warning("Factions check failed, allowing break: " + t);
            }
            return true;
        }
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}
