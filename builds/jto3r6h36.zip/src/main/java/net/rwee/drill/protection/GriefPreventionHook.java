package net.rwee.drill.protection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * GriefPrevention hook. Uses reflection so the plugin builds without the GriefPrevention jar.
 */
public class GriefPreventionHook
implements LandProtectionHook {
    private final boolean enabled;
    private final Plugin owner;
    private boolean failureLogged = false;

    public GriefPreventionHook(Plugin plugin) {
        boolean pluginEnabled = false;
        try {
            Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
            pluginEnabled = gp != null && gp.isEnabled();
        }
        catch (Exception e) {
            plugin.getLogger().warning("Error initializing GriefPrevention hook: " + e.toString());
        }
        this.enabled = pluginEnabled;
        this.owner = plugin;
    }

    @Override
    public boolean canBreak(Player player, Block block) {
        if (!this.enabled) {
            return true;
        }
        try {
            Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
            if (gp == null) {
                return true;
            }
            ClassLoader cl = gp.getClass().getClassLoader();
            Class<?> gpClass = Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention", true, cl);
            Field instanceField = gpClass.getField("instance");
            Object instance = instanceField.get(null);
            if (instance == null) {
                return true;
            }
            Object dataStore = gpClass.getField("dataStore").get(instance);
            if (dataStore == null) {
                return true;
            }
            Method getClaimAt = null;
            for (Method m : dataStore.getClass().getMethods()) {
                if (m.getName().equals("getClaimAt") && m.getParameterCount() == 3 && m.getParameterTypes()[0] == Location.class) {
                    getClaimAt = m;
                    break;
                }
            }
            if (getClaimAt == null) {
                return true;
            }
            Object claim = getClaimAt.invoke(dataStore, block.getLocation(), false, null);
            if (claim == null) {
                return true;
            }
            Method allowBreak = claim.getClass().getMethod("allowBreak", Player.class, Material.class);
            return allowBreak.invoke(claim, player, block.getType()) == null;
        }
        catch (Throwable t) {
            if (!this.failureLogged) {
                this.failureLogged = true;
                this.owner.getLogger().warning("GriefPrevention check failed, allowing break: " + t);
            }
            return true;
        }
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}
