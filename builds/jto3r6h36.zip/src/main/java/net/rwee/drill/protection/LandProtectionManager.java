/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package net.rwee.drill.protection;

import java.util.ArrayList;
import java.util.List;
import net.rwee.drill.protection.FactionsUUIDHook;
import net.rwee.drill.protection.GriefPreventionHook;
import net.rwee.drill.protection.LandProtectionHook;
import net.rwee.drill.protection.LandsHook;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LandProtectionManager {
    private final List<LandProtectionHook> activeHooks = new ArrayList<LandProtectionHook>();

    public LandProtectionManager(Plugin plugin) {
        GriefPreventionHook griefPrevention = new GriefPreventionHook(plugin);
        LandsHook lands = new LandsHook(plugin);
        FactionsUUIDHook factions = new FactionsUUIDHook(plugin);
        if (griefPrevention.isEnabled()) {
            this.activeHooks.add(griefPrevention);
        }
        if (lands.isEnabled()) {
            this.activeHooks.add(lands);
        }
        if (factions.isEnabled()) {
            this.activeHooks.add(factions);
        }
    }

    public boolean canBreak(Player player, Block block) {
        for (LandProtectionHook hook : this.activeHooks) {
            if (hook.canBreak(player, block)) continue;
            return false;
        }
        return true;
    }
}

