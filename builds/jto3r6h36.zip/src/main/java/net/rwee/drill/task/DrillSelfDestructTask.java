/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package net.rwee.drill.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.ColorFormater;
import net.rwee.drill.utils.DrillUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class DrillSelfDestructTask
extends BukkitRunnable {
    private final DrillPickaxePlugin plugin;
    private final NamespacedKey timeKey;
    private final Set<String> countdownShown;
    private final Map<UUID, Map<Integer, String>> lastLoreCache;

    public DrillSelfDestructTask(DrillPickaxePlugin plugin) {
        this.plugin = plugin;
        this.timeKey = new NamespacedKey((Plugin)plugin, "self_destruct_time");
        this.countdownShown = new HashSet<String>();
        this.lastLoreCache = new HashMap<UUID, Map<Integer, String>>();
    }

    public void run() {
        long currentTime = System.currentTimeMillis() / 1000L;
        for (Player player : Bukkit.getOnlinePlayers()) {
            Map playerLoreCache = this.lastLoreCache.computeIfAbsent(player.getUniqueId(), k -> new HashMap());
            ItemStack[] contents = player.getInventory().getContents();
            for (int slot = 0; slot < contents.length; ++slot) {
                long timeRemaining;
                ItemStack item = contents[slot];
                if (item == null || item.getType() == Material.AIR) {
                    playerLoreCache.remove(slot);
                    continue;
                }
                if (!DrillUtils.isDrillPickaxe(item)) {
                    playerLoreCache.remove(slot);
                    continue;
                }
                String drillType = DrillUtils.getDrillType(item);
                if (drillType == null) continue;
                if (!this.isSelfDestructEnabled(drillType)) {
                    String cacheKey = "disabled_" + drillType;
                    if (cacheKey.equals(playerLoreCache.get(slot))) continue;
                    this.updateDrillLoreDisabled(item, drillType);
                    playerLoreCache.put(slot, cacheKey);
                    continue;
                }
                ItemMeta meta = item.getItemMeta();
                if (meta == null) continue;
                Long destructTime = (Long)meta.getPersistentDataContainer().get(this.timeKey, PersistentDataType.LONG);
                if (destructTime == null) {
                    int timerSeconds = this.getSelfDestructTimer(drillType);
                    if (timerSeconds == -1) continue;
                    destructTime = currentTime + (long)timerSeconds;
                    meta.getPersistentDataContainer().set(this.timeKey, PersistentDataType.LONG, destructTime);
                    item.setItemMeta(meta);
                }
                if ((timeRemaining = destructTime - currentTime) <= 0L) {
                    this.destroyDrill(player, slot);
                    playerLoreCache.remove(slot);
                    continue;
                }
                this.checkAndShowCountdown(player, item, timeRemaining);
                String timeString = this.formatTime(timeRemaining);
                String cachedTime = (String)playerLoreCache.get(slot);
                if (timeString.equals(cachedTime)) continue;
                this.updateDrillLore(item, timeRemaining, drillType);
                playerLoreCache.put(slot, timeString);
            }
        }
        this.lastLoreCache.keySet().removeIf(uuid -> Bukkit.getPlayer((UUID)uuid) == null);
    }

    private boolean isSelfDestructEnabled(String drillType) {
        Object path = drillType.equals("legacy") ? "drill-pickaxe.self-destruct.enabled" : "drill-pickaxes." + drillType + ".self-destruct.enabled";
        return this.plugin.getConfig().getBoolean((String)path, false);
    }

    private int getSelfDestructTimer(String drillType) {
        Object path = drillType.equals("legacy") ? "drill-pickaxe.self-destruct.timer" : "drill-pickaxes." + drillType + ".self-destruct.timer";
        return this.plugin.getConfig().getInt((String)path, -1);
    }

    private void updateDrillLoreDisabled(ItemStack item, String drillType) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        List<String> originalLore = this.getOriginalLore(drillType);
        ArrayList<String> updatedLore = new ArrayList<String>();
        String disabledText = "DISABLED";
        for (String line : originalLore) {
            String formattedLine = ColorFormater.hex(line.replace("{time_remaining}", disabledText));
            updatedLore.add(formattedLine);
        }
        meta.setLore(updatedLore);
        item.setItemMeta(meta);
    }

    private void updateDrillLore(ItemStack item, long timeRemaining, String drillType) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        List<String> originalLore = this.getOriginalLore(drillType);
        ArrayList<String> updatedLore = new ArrayList<String>();
        String timeString = this.formatTime(timeRemaining);
        for (String line : originalLore) {
            String formattedLine = ColorFormater.hex(line.replace("{time_remaining}", timeString));
            updatedLore.add(formattedLine);
        }
        meta.setLore(updatedLore);
        item.setItemMeta(meta);
    }

    private List<String> getOriginalLore(String drillType) {
        if (drillType.equals("legacy")) {
            return this.plugin.getConfig().getStringList("drill-pickaxe.lore");
        }
        return this.plugin.getConfig().getStringList("drill-pickaxes." + drillType + ".lore");
    }

    private void checkAndShowCountdown(Player player, ItemStack item, long timeRemaining) {
        int[] countdownPoints;
        for (int countdown : countdownPoints = new int[]{20, 15, 10, 5, 4, 3, 2, 1}) {
            String countdownKey;
            if (timeRemaining != (long)countdown || this.countdownShown.contains(countdownKey = String.valueOf(player.getUniqueId()) + ":" + item.hashCode() + ":" + countdown)) continue;
            this.showCountdownMessage(player, countdown, item);
            this.countdownShown.add(countdownKey);
        }
        if (timeRemaining <= 0L || timeRemaining > 21L) {
            this.countdownShown.removeIf(key -> key.startsWith(String.valueOf(player.getUniqueId()) + ":" + item.hashCode()));
        }
    }

    private void showCountdownMessage(Player player, long timeRemaining, ItemStack drill) {
        String drillName = "Drill";
        if (drill != null && drill.hasItemMeta() && drill.getItemMeta().hasDisplayName()) {
            drillName = drill.getItemMeta().getDisplayName();
        }
        HashMap<String, String> placeholders = new HashMap<String, String>();
        placeholders.put("{time}", String.valueOf(timeRemaining));
        placeholders.put("{drill}", drillName);
        this.plugin.getMessageManager().sendMessage(player, "self-destruct-countdown", placeholders);
        float pitch = 0.5f + 0.1f * (float)(21L - timeRemaining);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, pitch);
    }

    private void destroyDrill(Player player, int slot) {
        String soundName = this.plugin.getConfig().getString("self-destruct.destruction-sound", "ENTITY_GENERIC_EXPLODE");
        try {
            Sound sound = Sound.valueOf((String)soundName);
            player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
        }
        catch (IllegalArgumentException e) {
            this.plugin.getLogger().warning("Invalid destruction sound: " + soundName);
        }
        player.getInventory().setItem(slot, new ItemStack(Material.AIR));
        this.countdownShown.removeIf(key -> key.startsWith(player.getUniqueId().toString()));
    }

    private String formatTime(long seconds) {
        if (seconds < 0L) {
            return "EXPIRED";
        }
        long hours = seconds / 3600L;
        long minutes = seconds % 3600L / 60L;
        long secs = seconds % 60L;
        if (hours > 0L) {
            return String.format("%dh %dm %ds", hours, minutes, secs);
        }
        if (minutes > 0L) {
            return String.format("%dm %ds", minutes, secs);
        }
        return String.format("%ds", secs);
    }
}

