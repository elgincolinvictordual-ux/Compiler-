/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package net.rwee.drill.utils;

import dev.respark.licensegate.LicenseGate;
import net.rwee.drill.lib.folialib.FoliaLib;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class License {
    private final JavaPlugin plugin;
    private final LicenseGate licenseGate;
    private final String productName;
    private final String licenseKey;
    private boolean isLicensed = false;
    private final FoliaLib foliaLib;

    public License(JavaPlugin plugin, String productName, String licenseKey) {
        this.plugin = plugin;
        this.licenseGate = new LicenseGate("a1c4a");
        this.productName = productName;
        this.licenseKey = licenseKey;
        this.foliaLib = new FoliaLib((Plugin)plugin);
    }

    private String getPlatformInfo() {
        if (this.foliaLib.isFolia()) {
            return "Folia";
        }
        if (this.foliaLib.isPaper()) {
            return "Paper";
        }
        if (this.foliaLib.isSpigot()) {
            return "Spigot";
        }
        return "Unknown";
    }

    public boolean initialize() {
        if (this.licenseKey == null || this.licenseKey.isEmpty()) {
            this.plugin.getLogger().severe("No license key provided in config.yml!");
            this.plugin.getLogger().severe("Please add 'license-key: YOUR_KEY_HERE' to your config.yml");
            return false;
        }
        if (!this.verifyLicense()) {
            this.plugin.getLogger().severe("License verification failed!");
            return false;
        }
        this.startPeriodicChecks();
        return true;
    }

    public boolean verifyLicense() {
        try {
            LicenseGate.ValidationType result = this.licenseGate.verify(this.licenseKey, this.productName);
            if (result.toString().equals("VALID")) {
                this.isLicensed = true;
                return true;
            }
            if (result.toString().equals("EXPIRED")) {
                this.isLicensed = false;
                this.plugin.getLogger().severe("License has expired for " + this.productName + "!");
                this.plugin.getLogger().severe("Please renew your license to continue using this plugin.");
                return false;
            }
            if (result.toString().equals("INVALID")) {
                this.isLicensed = false;
                this.plugin.getLogger().severe("Invalid license key for " + this.productName + "!");
                this.plugin.getLogger().severe("Please check your license key in config.yml");
                return false;
            }
            this.isLicensed = false;
            this.plugin.getLogger().severe("License verification failed with result: " + String.valueOf((Object)result));
            this.plugin.getLogger().severe("Please contact support if you believe this is an error.");
            return false;
        }
        catch (Exception e) {
            this.isLicensed = false;
            this.plugin.getLogger().severe("License verification error: " + e.getMessage());
            this.plugin.getLogger().severe("Please check your internet connection and try again.");
            return false;
        }
    }

    public boolean isLicensed() {
        return this.isLicensed;
    }

    public boolean checkLicenseAndDisableIfInvalid() {
        if (!this.isLicensed) {
            this.plugin.getLogger().severe("Attempting to use unlicensed plugin! Disabling...");
            this.foliaLib.getScheduler().runNextTick(task -> this.plugin.getServer().getPluginManager().disablePlugin((Plugin)this.plugin));
            return false;
        }
        return true;
    }

    public boolean quickCheck() {
        return this.isLicensed;
    }

    private void startPeriodicChecks() {
        try {
            this.foliaLib.getScheduler().runTimerAsync(task -> {
                if (!this.verifyLicense()) {
                    this.plugin.getLogger().severe("Periodic license check failed! Disabling plugin.");
                    this.foliaLib.getScheduler().runNextTick(disableTask -> this.plugin.getServer().getPluginManager().disablePlugin((Plugin)this.plugin));
                }
            }, 36000L, 36000L);
        }
        catch (Exception e) {
            this.plugin.getLogger().severe("Failed to start periodic license checks: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String createServerIdentifier() {
        String serverIP = this.plugin.getServer().getIp();
        int serverPort = this.plugin.getServer().getPort();
        String serverName = this.plugin.getServer().getName();
        if (serverIP == null || serverIP.isEmpty()) {
            serverIP = "localhost";
        }
        return serverName + "_" + serverIP + ":" + serverPort;
    }

    public void cleanup() {
        if (this.foliaLib != null) {
            this.foliaLib.getScheduler().cancelAllTasks();
        }
        this.isLicensed = false;
    }

    public String getLicenseInfo() {
        return "Product: " + this.productName + " | Status: " + (this.isLicensed ? "Valid" : "Invalid") + " | Platform: " + this.getPlatformInfo();
    }

    public FoliaLib getFoliaLib() {
        return this.foliaLib;
    }
}

