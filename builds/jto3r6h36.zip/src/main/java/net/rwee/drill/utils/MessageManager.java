/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 */
package net.rwee.drill.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.rwee.drill.DrillPickaxePlugin;
import net.rwee.drill.utils.ColorFormater;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class MessageManager {
    private final DrillPickaxePlugin plugin;
    private FileConfiguration messagesConfig;
    private File messagesFile;
    private final Map<String, MessageData> messageCache;

    public MessageManager(DrillPickaxePlugin plugin) {
        this.plugin = plugin;
        this.messageCache = new HashMap<String, MessageData>();
        this.loadMessagesConfig();
        this.cacheMessages();
    }

    private void loadMessagesConfig() {
        this.messagesFile = new File(this.plugin.getDataFolder(), "messages.yml");
        if (!this.messagesFile.exists()) {
            this.plugin.saveResource("messages.yml", false);
        }
        this.messagesConfig = YamlConfiguration.loadConfiguration((File)this.messagesFile);
        InputStream defConfigStream = this.plugin.getResource("messages.yml");
        if (defConfigStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration((Reader)new InputStreamReader(defConfigStream));
            this.messagesConfig.setDefaults((Configuration)defConfig);
        }
    }

    public void reloadMessages() {
        this.messagesConfig = YamlConfiguration.loadConfiguration((File)this.messagesFile);
        this.messageCache.clear();
        this.cacheMessages();
    }

    public void saveMessages() {
        try {
            this.messagesConfig.save(this.messagesFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().severe("Could not save messages.yml: " + e.getMessage());
        }
    }

    private void cacheMessages() {
        if (!this.messagesConfig.contains("messages")) {
            this.plugin.getLogger().warning("No messages section found in messages.yml!");
            return;
        }
        for (String key : this.messagesConfig.getConfigurationSection("messages").getKeys(false)) {
            DisplayType display;
            String text = this.messagesConfig.getString("messages." + key + ".text", "");
            String displayStr = this.messagesConfig.getString("messages." + key + ".display", "BOTH");
            try {
                display = DisplayType.valueOf(displayStr.toUpperCase());
            }
            catch (IllegalArgumentException e) {
                this.plugin.getLogger().warning("Invalid display type '" + displayStr + "' for message '" + key + "'. Using BOTH.");
                display = DisplayType.BOTH;
            }
            this.messageCache.put(key, new MessageData(text, display));
        }
    }

    public void sendMessage(Player player, String messageKey) {
        this.sendMessage(player, messageKey, new HashMap<String, String>());
    }

    public void sendMessage(Player player, String messageKey, Map<String, String> placeholders) {
        if (player == null) {
            return;
        }
        MessageData data = this.messageCache.get(messageKey);
        if (data == null) {
            this.plugin.getLogger().warning("Message key '" + messageKey + "' not found in messages.yml!");
            return;
        }
        if (data.display == DisplayType.NONE) {
            return;
        }
        String formattedMessage = ColorFormater.hex(data.text);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            formattedMessage = formattedMessage.replace(entry.getKey(), entry.getValue());
        }
        switch (data.display.ordinal()) {
            case 0: {
                player.sendMessage(formattedMessage);
                break;
            }
            case 1: {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR, (BaseComponent)new TextComponent(formattedMessage));
                break;
            }
            case 2: {
                player.sendMessage(formattedMessage);
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR, (BaseComponent)new TextComponent(formattedMessage));
            }
        }
    }

    public String getRawMessage(String messageKey) {
        MessageData data = this.messageCache.get(messageKey);
        return data != null ? data.text : "";
    }

    public DisplayType getDisplayType(String messageKey) {
        MessageData data = this.messageCache.get(messageKey);
        return data != null ? data.display : DisplayType.BOTH;
    }

    public FileConfiguration getMessagesConfig() {
        return this.messagesConfig;
    }

    public static enum DisplayType {
        CHAT,
        ACTIONBAR,
        BOTH,
        NONE;

    }

    private static class MessageData {
        String text;
        DisplayType display;

        MessageData(String text, DisplayType display) {
            this.text = text;
            this.display = display;
        }
    }
}

